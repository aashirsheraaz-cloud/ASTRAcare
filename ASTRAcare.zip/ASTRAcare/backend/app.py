
from functools import wraps
import sqlite3
import os

from flask import (
    Flask, jsonify, render_template, request,
    redirect, url_for, flash, session
)

from werkzeug.security import (
    generate_password_hash,
    check_password_hash
)

from database import (
    initialize_database,
    get_latest_reading,
    add_health_reading,
    get_health_history,
    get_total_readings_count,
    create_user,
    get_user_by_email,
    get_user_by_id,
    update_user_profile,
    get_mission_by_id,
    get_all_missions,
    create_mission,
    get_all_users,
    get_users_assigned_to_mission,
    assign_user_to_mission,
    update_mission,
    delete_mission,
    unassign_user_from_mission,
    get_health_alerts_for_mission,
    resolve_health_alert,
    get_health_history_for_mission,
    get_health_alert_by_id,
    get_user_mission_role,
    get_mission_creator
)


# --------------------------------------------------
# FLASK APPLICATION
# --------------------------------------------------

app = Flask(
    __name__,
    template_folder="templates",
    static_folder="../static",
    static_url_path="/static"
)

app.secret_key = os.environ.get(
    "FLASK_SECRET_KEY",
    "astracare-development-secret-change-before-deployment"
)


# --------------------------------------------------
# AUTHENTICATION DECORATORS
# --------------------------------------------------

def login_required(route_function):

    @wraps(route_function)
    def wrapper(*args, **kwargs):

        if "user_id" not in session:
            flash("Please log in to access Mission Control.")
            return redirect(url_for("login"))

        return route_function(*args, **kwargs)

    return wrapper


def api_login_required(route_function):

    @wraps(route_function)
    def wrapper(*args, **kwargs):

        if "user_id" not in session:
            return jsonify({
                "error": "Unauthorized. Please log in."
            }), 401

        return route_function(*args, **kwargs)

    return wrapper


# --------------------------------------------------
# MISSION ROLE HELPERS
# --------------------------------------------------

def get_current_user():
    return get_user_by_id(session["user_id"])


def user_has_mission_role(user_id, mission_id, allowed_roles):

    role = get_user_mission_role(user_id, mission_id)

    return role in allowed_roles


def get_mission_captain(mission_id):

    assigned_users = get_users_assigned_to_mission(mission_id)

    for member in assigned_users:
        if member["mission_role"] == "Captain":
            return member

    return None


# --------------------------------------------------
# HEALTH MONITORING
# --------------------------------------------------

def check_health_anomalies(reading):

    alerts = []

    if reading["heart_rate"] < 60:
        alerts.append("Low simulated heart rate detected.")

    if reading["heart_rate"] > 100:
        alerts.append("High simulated heart rate detected.")

    if reading["spo2"] < 95:
        alerts.append("Low simulated blood oxygen reading detected.")

    if reading["sleep_hours"] < 6:
        alerts.append("Short sleep duration detected.")

    if reading["fatigue_level"] >= 7:
        alerts.append("High fatigue score detected.")

    return alerts


def get_response_procedure(alert_message):

    procedures = {

        "High simulated heart rate detected.": [
            "Ask the astronaut to verify that the wearable sensor is correctly positioned.",
            "Repeat the measurement using the approved onboard monitoring procedure.",
            "Ask the astronaut to report any symptoms or unusual discomfort.",
            "Notify the onboard medical officer or flight surgeon if the reading remains abnormal or symptoms are reported."
        ],

        "Low simulated heart rate detected.": [
            "Verify sensor placement and repeat the measurement.",
            "Check the astronaut's reported condition and symptoms.",
            "Notify the onboard medical officer or flight surgeon if the reading remains abnormal or symptoms are reported."
        ],

        "Low simulated blood oxygen reading detected.": [
            "Check sensor contact and signal quality.",
            "Repeat the measurement using the approved onboard procedure.",
            "Ask the astronaut to report any breathing difficulty or other symptoms.",
            "Escalate persistent low readings or symptoms immediately through the spacecraft medical response protocol."
        ],

        "Short sleep duration detected.": [
            "Review the astronaut's recent sleep records.",
            "Check the crew schedule and sleep environment.",
            "Coordinate an appropriate rest opportunity.",
            "Refer persistent sleep difficulties to the onboard medical officer."
        ],

        "High fatigue score detected.": [
            "Ask the astronaut to confirm their fatigue assessment.",
            "Review recent workload and sleep history.",
            "Reassess the astronaut's fitness for safety-critical duties.",
            "Coordinate rest and notify the appropriate medical or mission personnel."
        ]

    }

    return procedures.get(
        alert_message,
        ["Review the alert and follow the approved mission response procedure."]
    )


# --------------------------------------------------
# DATABASE INITIALIZATION
# --------------------------------------------------

initialize_database()


# --------------------------------------------------
# MAIN DASHBOARD
# --------------------------------------------------

@app.route("/")
@login_required
def home():

    user_id = session["user_id"]

    user = get_user_by_id(user_id)

    if user is None:
        session.clear()
        return redirect(url_for("login"))

    reading = get_latest_reading(user_id)

    if reading is None:

        add_health_reading(
            82, 97, 7.5, 3, user_id
        )

        reading = get_latest_reading(user_id)

    # These legacy fields are used only for the
    # existing personal dashboard display.
    # Mission authorization uses mission_members.
    astronaut = {
        "name": user["name"],
        "mission": user["mission_id"],
        "crew_id": user["crew_id"],
        "mission_role": user["mission_role"],
        **reading
    }

    alerts = check_health_anomalies(reading)

    return render_template(
        "index.html",
        astronaut=astronaut,
        alerts=alerts
    )


# --------------------------------------------------
# MISSION MANAGEMENT
# --------------------------------------------------

@app.route("/missions")
@login_required
def mission_management():

    missions = get_all_missions()

    return render_template(
        "missions.html",
        missions=missions
    )


# --------------------------------------------------
# MISSION DETAILS
# ALL ASSIGNED CREW CAN ACCESS
# --------------------------------------------------

@app.route("/missions/<mission_id>")
@login_required
def mission_details(mission_id):

    mission = get_mission_by_id(mission_id)

    if mission is None:
        flash("Mission not found.", "error")
        return redirect(url_for("mission_management"))

    current_user = get_current_user()

    if current_user is None:
        session.clear()
        return redirect(url_for("login"))

    user_id = session["user_id"]

    # Get the user's role specifically for this mission.
    role = get_user_mission_role(user_id, mission_id)

    # Check whether this user created the mission.
    mission_creator = get_mission_creator(mission_id)

    # Check whether the mission already has a Captain.
    captain = get_mission_captain(mission_id)

    has_membership = role in [
        "Captain",
        "Medic",
        "Astronaut"
    ]

    can_appoint_first_captain = (
        mission_creator == user_id
        and captain is None
    )

    # A creator can access an unassigned mission
    # only while it has no Captain.
    if not has_membership and not can_appoint_first_captain:
        flash(
            "You do not have permission to view this mission.",
            "error"
        )
        return redirect(url_for("home"))

    users = get_all_users()

    assigned_users = get_users_assigned_to_mission(mission_id)

    # --------------------------------------------------
    # ROLE PERMISSIONS
    # --------------------------------------------------

    can_manage_crew = role == "Captain"

    can_view_alerts = role in [
        "Captain",
        "Medic"
    ]

    can_resolve_alerts = role == "Medic"

    can_view_health_history = role in [
        "Captain",
        "Medic"
    ]

    # Only Captain and Medic can view the aggregate
    # Crew Health Overview and historical information.
    health_readings = (
        get_health_history_for_mission(mission_id)
        if can_view_health_history
        else []
    )

    health_alerts = (
        get_health_alerts_for_mission(mission_id)
        if can_view_alerts
        else []
    )

    for alert in health_alerts:
        alert["procedure"] = get_response_procedure(
            alert["alert_message"]
        )

    return render_template(
        "mission_details.html",
        mission=mission,
        users=users,
        assigned_users=assigned_users,
        health_alerts=health_alerts,
        health_readings=health_readings,
        current_user=current_user,

        can_manage_crew=can_manage_crew,
        can_view_alerts=can_view_alerts,
        can_resolve_alerts=can_resolve_alerts,
        can_view_health_history=can_view_health_history,

        can_appoint_first_captain=can_appoint_first_captain,
        mission_creator=mission_creator,
        captain=captain
    )


# --------------------------------------------------
# CHECK ALERT RECOVERY
# --------------------------------------------------

def alert_condition_recovered(alert_message, reading):

    if alert_message == "Low simulated heart rate detected.":
        return reading["heart_rate"] >= 60

    if alert_message == "High simulated heart rate detected.":
        return reading["heart_rate"] <= 100

    if alert_message == "Low simulated blood oxygen reading detected.":
        return reading["spo2"] >= 95

    if alert_message == "Short sleep duration detected.":
        return reading["sleep_hours"] >= 6

    if alert_message == "High fatigue score detected.":
        return reading["fatigue_level"] < 7

    return False


# --------------------------------------------------
# RESOLVE HEALTH ALERT
# MEDICS ONLY
# --------------------------------------------------

@app.route(
    "/missions/alerts/<int:alert_id>/recheck",
    methods=["POST"]
)
@login_required
def recheck_health_alert(alert_id):

    current_user = get_current_user()

    if current_user is None:
        session.clear()
        return redirect(url_for("login"))

    alert = get_health_alert_by_id(alert_id)

    if alert is None:
        flash("Alert not found.", "error")
        return redirect(url_for("home"))

    mission_id = alert["mission_id"]

    if not mission_id:
        flash("This alert is not associated with a mission.", "error")
        return redirect(url_for("home"))

    # Verify Medic role for the alert's actual mission.
    if not user_has_mission_role(
        session["user_id"],
        mission_id,
        ["Medic"]
    ):
        flash(
            "Only a Medic assigned to this mission can perform health rechecks.",
            "error"
        )
        return redirect(url_for("home"))

    if alert["is_resolved"]:
        flash("This alert has already been resolved.", "error")
        return redirect(
            url_for("mission_details", mission_id=mission_id)
        )

    try:

        heart_rate = int(request.form["heart_rate"])
        spo2 = int(request.form["spo2"])
        sleep_hours = float(request.form["sleep_hours"])
        fatigue_level = int(request.form["fatigue_level"])

        if not 30 <= heart_rate <= 220:
            raise ValueError()

        if not 50 <= spo2 <= 100:
            raise ValueError()

        if not 0 <= sleep_hours <= 24:
            raise ValueError()

        if not 0 <= fatigue_level <= 10:
            raise ValueError()

    except (KeyError, TypeError, ValueError):

        flash("Please enter valid health readings.", "error")

        return redirect(
            url_for("mission_details", mission_id=mission_id)
        )

    reading = {
        "heart_rate": heart_rate,
        "spo2": spo2,
        "sleep_hours": sleep_hours,
        "fatigue_level": fatigue_level
    }

    # Save a NEW reading for the affected astronaut.
    # Associate the new reading's alerts with this mission.
    add_health_reading(
    heart_rate,
    spo2,
    sleep_hours,
    fatigue_level,
    alert["user_id"],
    mission_id
)

    # Resolve only if the original abnormal condition
    # has recovered according to the new reading.
    if alert_condition_recovered(
        alert["alert_message"],
        reading
    ):

        resolved = resolve_health_alert(
            alert_id,
            session["user_id"]
        )

        if resolved:
            flash(
                "New reading recorded. Alert resolved successfully.",
                "success"
            )
        else:
            flash(
                "Could not resolve the alert.",
                "error"
            )

    else:

        flash(
            "New reading recorded, but the abnormal condition remains. "
            "The alert is still active.",
            "error"
        )

    return redirect(
        url_for("mission_details", mission_id=mission_id)
    )


# --------------------------------------------------
# ASSIGN CREW / APPOINT FIRST CAPTAIN
# --------------------------------------------------

@app.route("/missions/assign", methods=["POST"])
@login_required
def assign_astronaut():

    mission_id = request.form.get(
        "mission_id", ""
    ).strip()

    user_id = request.form.get(
        "user_id", ""
    ).strip()

    mission_role = request.form.get(
        "mission_role", ""
    ).strip()

    if not mission_id:
        flash("Mission ID is missing.", "error")
        return redirect(url_for("mission_management"))

    mission = get_mission_by_id(mission_id)

    if mission is None:
        flash("Mission not found.", "error")
        return redirect(url_for("mission_management"))

    current_user = get_current_user()

    if current_user is None:
        session.clear()
        return redirect(url_for("login"))

    # --------------------------------------------------
    # FIRST CAPTAIN APPOINTMENT
    # --------------------------------------------------

    captain = get_mission_captain(mission_id)

    if captain is None:

        mission_creator = get_mission_creator(mission_id)

        # Only the mission creator can appoint the first Captain.
        if mission_creator != session["user_id"]:
            flash(
                "Only the mission creator can appoint its first Captain.",
                "error"
            )
            return redirect(
                url_for("mission_details", mission_id=mission_id)
            )

        if mission_role != "Captain":
            flash(
                "The first crew assignment must be a Captain.",
                "error"
            )
            return redirect(
                url_for("mission_details", mission_id=mission_id)
            )

    # --------------------------------------------------
    # NORMAL CREW ASSIGNMENT
    # --------------------------------------------------

    else:

        # Once a Captain exists, only that mission's Captain
        # can assign additional crew.
        if not user_has_mission_role(
            session["user_id"],
            mission_id,
            ["Captain"]
        ):
            flash(
                "Only this mission's Captain can assign crew.",
                "error"
            )
            return redirect(
                url_for("mission_details", mission_id=mission_id)
            )

        # Normal assignments cannot appoint another Captain.
        if mission_role == "Captain":
            flash(
                "This mission already has a Captain.",
                "error"
            )
            return redirect(
                url_for("mission_details", mission_id=mission_id)
            )

        if mission_role not in ["Medic", "Astronaut"]:
            flash("Invalid crew role.", "error")
            return redirect(
                url_for("mission_details", mission_id=mission_id)
            )

    if not user_id:
        flash("Please select a crew member.", "error")
        return redirect(
            url_for("mission_details", mission_id=mission_id)
        )

    try:
        user_id = int(user_id)

    except (ValueError, TypeError):

        flash("Invalid crew member selection.", "error")

        return redirect(
            url_for("mission_details", mission_id=mission_id)
        )

    astronaut = get_user_by_id(user_id)

    if astronaut is None:
        flash("Crew member account not found.", "error")
        return redirect(
            url_for("mission_details", mission_id=mission_id)
        )

    updated, message = assign_user_to_mission(
        user_id,
        mission_id,
        mission_role
    )

    flash(
        f"{astronaut['name']}: {message}",
        "success" if updated else "error"
    )

    return redirect(
        url_for("mission_details", mission_id=mission_id)
    )


# --------------------------------------------------
# UNASSIGN CREW
# CAPTAIN ONLY
# --------------------------------------------------

@app.route("/missions/unassign", methods=["POST"])
@login_required
def unassign_astronaut():

    mission_id = request.form.get(
        "mission_id", ""
    ).strip()

    user_id = request.form.get(
        "user_id", ""
    ).strip()

    if not mission_id:
        flash("Mission ID is missing.", "error")
        return redirect(url_for("mission_management"))

    if not user_has_mission_role(
        session["user_id"],
        mission_id,
        ["Captain"]
    ):
        flash(
            "Only this mission's Captain can unassign crew.",
            "error"
        )
        return redirect(
            url_for("mission_details", mission_id=mission_id)
        )

    try:
        user_id = int(user_id)

    except (ValueError, TypeError):

        flash("Invalid crew member selection.", "error")

        return redirect(
            url_for("mission_details", mission_id=mission_id)
        )

    astronaut = get_user_by_id(user_id)

    if astronaut is None:
        flash("Crew member account not found.", "error")
        return redirect(
            url_for("mission_details", mission_id=mission_id)
        )

    target_role = get_user_mission_role(
        user_id,
        mission_id
    )

    if target_role is None:
        flash(
            "This user is not assigned to this mission.",
            "error"
        )
        return redirect(
            url_for("mission_details", mission_id=mission_id)
        )

    if target_role == "Captain":
        flash(
            "The Captain cannot be unassigned. Complete a command handover first.",
            "error"
        )
        return redirect(
            url_for("mission_details", mission_id=mission_id)
        )

    updated = unassign_user_from_mission(
        user_id,
        mission_id
    )

    if updated:
        flash(
            f"{astronaut['name']} has been unassigned from this mission.",
            "success"
        )
    else:
        flash(
            "Could not unassign this crew member.",
            "error"
        )

    return redirect(
        url_for("mission_details", mission_id=mission_id)
    )


# --------------------------------------------------
# CREATE MISSION
# --------------------------------------------------

@app.route("/missions/create", methods=["POST"])
@login_required
def create_new_mission():

    mission_id = request.form.get(
        "mission_id", ""
    ).strip().upper()

    mission_name = request.form.get(
        "mission_name", ""
    ).strip()

    destination = request.form.get(
        "destination", ""
    ).strip()

    launch_date = request.form.get(
        "launch_date", ""
    ).strip()

    status = request.form.get(
        "status", ""
    ).strip()

    description = request.form.get(
        "description", ""
    ).strip()

    if not all([
        mission_id,
        mission_name,
        destination,
        status
    ]):
        flash(
            "Please complete all required mission fields.",
            "error"
        )
        return redirect(url_for("mission_management"))

    if status not in [
        "Planned",
        "Active",
        "Completed",
        "Cancelled"
    ]:
        flash("Invalid mission status.", "error")
        return redirect(url_for("mission_management"))

    try:

        create_mission(
            mission_id,
            mission_name,
            destination,
            launch_date or None,
            status,
            description,
            session["user_id"]
        )

        flash(
            "Mission created successfully! Now appoint its first Captain.",
            "success"
        )

        return redirect(
            url_for("mission_details", mission_id=mission_id)
        )

    except sqlite3.IntegrityError:

        flash(
            "A mission with this ID already exists.",
            "error"
        )

        return redirect(url_for("mission_management"))


# --------------------------------------------------
# EDIT MISSION
# CAPTAIN ONLY
# --------------------------------------------------

@app.route("/missions/edit", methods=["POST"])
@login_required
def edit_mission():

    original_id = request.form.get(
        "original_id", ""
    ).strip()

    if not original_id:
        flash("Invalid original mission ID.", "error")
        return redirect(url_for("mission_management"))

    if not user_has_mission_role(
        session["user_id"],
        original_id,
        ["Captain"]
    ):
        flash(
            "Only this mission's Captain can edit it.",
            "error"
        )
        return redirect(url_for("home"))

    mission = get_mission_by_id(original_id)

    if mission is None:
        flash("Mission not found.", "error")
        return redirect(url_for("mission_management"))

    mission_id = request.form.get(
        "mission_id", ""
    ).strip().upper()

    mission_name = request.form.get(
        "mission_name", ""
    ).strip()

    destination = request.form.get(
        "destination", ""
    ).strip()

    launch_date = request.form.get(
        "launch_date", ""
    ).strip()

    status = request.form.get(
        "status", ""
    ).strip()

    description = request.form.get(
        "description", ""
    ).strip()

    if not all([
        mission_id,
        mission_name,
        destination,
        status
    ]):
        flash(
            "Please complete all required mission fields.",
            "error"
        )
        return redirect(
            url_for("mission_details", mission_id=original_id)
        )

    if status not in [
        "Planned",
        "Active",
        "Completed",
        "Cancelled"
    ]:
        flash("Invalid mission status.", "error")
        return redirect(
            url_for("mission_details", mission_id=original_id)
        )

    try:

        update_mission(
            original_id,
            mission_id,
            mission_name,
            destination,
            launch_date or None,
            status,
            description
        )

        flash("Mission updated successfully!", "success")

        return redirect(
            url_for("mission_details", mission_id=mission_id)
        )

    except sqlite3.IntegrityError:

        flash(
            "That Mission ID already exists. Please choose another.",
            "error"
        )

        return redirect(
            url_for("mission_details", mission_id=original_id)
        )


# --------------------------------------------------
# DELETE MISSION
# CAPTAIN ONLY
# --------------------------------------------------

@app.route("/missions/delete", methods=["POST"])
@login_required
def delete_existing_mission():

    mission_id = request.form.get(
        "mission_id", ""
    ).strip()

    if not mission_id:
        flash("Invalid mission ID.", "error")
        return redirect(url_for("mission_management"))

    if not user_has_mission_role(
        session["user_id"],
        mission_id,
        ["Captain"]
    ):
        flash(
            "Only this mission's Captain can delete it.",
            "error"
        )
        return redirect(url_for("home"))

    try:

        deleted = delete_mission(mission_id)

        if deleted:
            flash("Mission deleted successfully!", "success")
        else:
            flash("Mission not found.", "error")

    except sqlite3.IntegrityError:

        flash(
            "This mission could not be deleted.",
            "error"
        )

    return redirect(url_for("mission_management"))


# --------------------------------------------------
# API STATUS
# --------------------------------------------------

@app.route("/api/status")
def status():

    return jsonify({
        "project": "ASTRAcare",
        "status": "Running"
    })


# --------------------------------------------------
# API HEALTH READINGS
# --------------------------------------------------

@app.route("/api/readings", methods=["GET", "POST"])
@api_login_required
def readings():

    user_id = session["user_id"]

    if request.method == "GET":

        reading = get_latest_reading(user_id)

        if reading is None:

            add_health_reading(
                82, 97, 7.5, 3, user_id
            )

            reading = get_latest_reading(user_id)

        alerts = check_health_anomalies(reading)

        return jsonify({
            "reading": reading,
            "alerts": alerts
        })

    data = request.get_json(silent=True) or {}

    try:

        heart_rate = int(data["heart_rate"])
        spo2 = int(data["spo2"])
        sleep_hours = float(data["sleep_hours"])
        fatigue_level = int(data["fatigue_level"])

        if not 30 <= heart_rate <= 220:
            return jsonify({
                "error": "Invalid heart rate"
            }), 400

        if not 50 <= spo2 <= 100:
            return jsonify({
                "error": "Invalid oxygen level"
            }), 400

        if not 0 <= sleep_hours <= 24:
            return jsonify({
                "error": "Invalid sleep duration"
            }), 400

        if not 0 <= fatigue_level <= 10:
            return jsonify({
                "error": "Invalid fatigue level"
            }), 400

        reading_id = add_health_reading(
            heart_rate,
            spo2,
            sleep_hours,
            fatigue_level,
            user_id
        )

        return jsonify({
            "message": "Health reading saved successfully!",
            "id": reading_id
        }), 201

    except (KeyError, TypeError, ValueError):

        return jsonify({
            "error": "Please provide valid health readings"
        }), 400


# --------------------------------------------------
# API HEALTH HISTORY
# --------------------------------------------------

@app.route("/api/history")
@api_login_required
def health_history():

    history = get_health_history(
        session["user_id"]
    )

    return jsonify(history)


# --------------------------------------------------
# API DASHBOARD SUMMARY
# --------------------------------------------------

@app.route("/api/summary")
@api_login_required
def dashboard_summary():

    history = get_health_history(
        session["user_id"]
    )

    if history:

        average_heart_rate = round(
            sum(item["heart_rate"] for item in history)
            / len(history),
            1
        )

        average_spo2 = round(
            sum(item["spo2"] for item in history)
            / len(history),
            1
        )

        active_alerts = sum(
            1 for item in history
            if (
                item["heart_rate"] > 100
                or item["heart_rate"] < 60
                or item["spo2"] < 95
                or item["sleep_hours"] < 6
                or item["fatigue_level"] >= 7
            )
        )

    else:

        average_heart_rate = 0
        average_spo2 = 0
        active_alerts = 0

    return jsonify({

        "total_readings": get_total_readings_count(
            session["user_id"]
        ),

        "average_heart_rate": average_heart_rate,

        "average_spo2": average_spo2,

        "active_alerts": active_alerts

    })


# --------------------------------------------------
# USER REGISTRATION
# --------------------------------------------------

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        name = request.form.get(
            "name", ""
        ).strip()

        email = request.form.get(
            "email", ""
        ).strip()

        password = request.form.get(
            "password", ""
        )

        confirm_password = request.form.get(
            "confirm_password", ""
        )

        if not name or not email or not password:
            flash("Please complete all fields.")
            return redirect(url_for("register"))

        if len(password) < 8:
            flash(
                "Password must contain at least 8 characters."
            )
            return redirect(url_for("register"))

        if password != confirm_password:
            flash("Passwords do not match.")
            return redirect(url_for("register"))

        password_hash = generate_password_hash(password)

        try:

            create_user(
                name,
                email,
                password_hash
            )

        except sqlite3.IntegrityError:

            flash(
                "An account with this email already exists."
            )
            return redirect(url_for("register"))

        flash(
            "Account created successfully! Please log in."
        )

        return redirect(url_for("login"))

    return render_template("register.html")


# --------------------------------------------------
# USER LOGIN
# --------------------------------------------------

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form.get(
            "email", ""
        ).strip()

        password = request.form.get(
            "password", ""
        )

        user = get_user_by_email(email)

        if user and check_password_hash(
            user["password_hash"],
            password
        ):

            session.clear()

            session["user_id"] = user["id"]
            session["user_name"] = user["name"]

            flash(
                "Login successful! Welcome to ASTRAcare."
            )

            return redirect(url_for("home"))

        flash("Invalid email or password.")

        return redirect(url_for("login"))

    return render_template("login.html")


# --------------------------------------------------
# LOGOUT
# --------------------------------------------------

@app.route("/logout")
def logout():

    session.clear()

    flash("You have successfully logged out.")

    return redirect(url_for("login"))


# --------------------------------------------------
# UPDATE ASTRONAUT PROFILE
# USERS CAN ONLY EDIT THEIR NAME
# --------------------------------------------------

@app.route("/profile", methods=["POST"])
@login_required
def update_profile():

    user_id = session["user_id"]

    name = request.form.get(
        "name", ""
    ).strip()

    if not name:
        flash("Please enter your name.", "error")
        return redirect(url_for("home"))

    update_user_profile(
        user_id,
        name
    )

    session["user_name"] = name

    flash(
        "Astronaut profile updated successfully!",
        "success"
    )

    return redirect(url_for("home"))


# --------------------------------------------------
# RUN APPLICATION
# --------------------------------------------------

if __name__ == "__main__":

    app.run(debug=True)
