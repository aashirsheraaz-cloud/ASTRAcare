
import sqlite3
from pathlib import Path


# --------------------------------------------------
# DATABASE LOCATION
# --------------------------------------------------

DB_PATH = (
    Path(__file__).resolve().parent.parent
    / "data"
    / "astracare.db"
)


# --------------------------------------------------
# DATABASE CONNECTION
# --------------------------------------------------

def get_connection():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)

    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")

    return connection


# --------------------------------------------------
# DATABASE INITIALIZATION AND MIGRATIONS
# --------------------------------------------------

def initialize_database():

    with get_connection() as connection:

        # USERS TABLE
        connection.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # HEALTH READINGS TABLE
        connection.execute("""
    CREATE TABLE IF NOT EXISTS health_readings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        mission_id TEXT,
        heart_rate INTEGER NOT NULL,
        spo2 INTEGER NOT NULL,
        sleep_hours REAL NOT NULL,
        fatigue_level INTEGER NOT NULL,
        recorded_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (mission_id)
            REFERENCES missions(mission_id)
            ON UPDATE CASCADE
            ON DELETE SET NULL
    )
""")

        # HEALTH ALERTS TABLE
        connection.execute("""
            CREATE TABLE IF NOT EXISTS health_alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                reading_id INTEGER NOT NULL,
                alert_message TEXT NOT NULL,
                resolved_at TEXT,
                resolved_by INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                is_resolved INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(id),
                FOREIGN KEY (reading_id)
                    REFERENCES health_readings(id)
                    ON DELETE CASCADE
            )
        """)

        # MISSIONS TABLE
        connection.execute("""
            CREATE TABLE IF NOT EXISTS missions (
                mission_id TEXT PRIMARY KEY,
                mission_name TEXT NOT NULL,
                destination TEXT NOT NULL,
                launch_date TEXT,
                status TEXT NOT NULL DEFAULT 'Planned',
                description TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # --------------------------------------------------
        # MIGRATE USERS TABLE
        # --------------------------------------------------

        user_columns = {
            row["name"]
            for row in connection.execute(
                "PRAGMA table_info(users)"
            ).fetchall()
        }

        if "crew_id" not in user_columns:
            connection.execute("""
                ALTER TABLE users
                ADD COLUMN crew_id TEXT DEFAULT ''
            """)

        if "mission_id" not in user_columns:
            connection.execute("""
                ALTER TABLE users
                ADD COLUMN mission_id TEXT
            """)

        if "mission_role" not in user_columns:
            connection.execute("""
                ALTER TABLE users
                ADD COLUMN mission_role TEXT DEFAULT 'Astronaut'
            """)

        connection.execute("""
            UPDATE users
            SET crew_id = 'AST-' || printf('%03d', id)
            WHERE crew_id IS NULL OR crew_id = ''
        """)

        connection.execute("""
            UPDATE users
            SET mission_role = 'Astronaut'
            WHERE mission_role IS NULL OR mission_role = ''
        """)

        # --------------------------------------------------
        # MIGRATE HEALTH READINGS
        # --------------------------------------------------

        reading_columns = {
            row["name"]
            for row in connection.execute(
                "PRAGMA table_info(health_readings)"
            ).fetchall()
        }

        if "user_id" not in reading_columns:
            connection.execute("""
                ALTER TABLE health_readings
                ADD COLUMN user_id INTEGER REFERENCES users(id)
            """)

        if "mission_id" not in reading_columns:
            connection.execute("""
                ALTER TABLE health_readings
                ADD COLUMN mission_id TEXT
            """)

# Assign old readings to a mission only when
# the astronaut belongs to exactly one mission.
        connection.execute("""
            UPDATE health_readings
            SET mission_id = (
                SELECT MIN(mm.mission_id)
                FROM mission_members mm
                WHERE mm.user_id = health_readings.user_id
            )
            WHERE mission_id IS NULL
            AND user_id IS NOT NULL
            AND (
                SELECT COUNT(*)
                FROM mission_members mm
                WHERE mm.user_id = health_readings.user_id
            ) = 1
        """)

        # --------------------------------------------------
        # MIGRATE HEALTH ALERTS
        # --------------------------------------------------

        alert_columns = {
            row["name"]
            for row in connection.execute(
                "PRAGMA table_info(health_alerts)"
            ).fetchall()
        }

        if "resolved_at" not in alert_columns:
            connection.execute("""
                ALTER TABLE health_alerts
                ADD COLUMN resolved_at TEXT
            """)

        if "resolved_by" not in alert_columns:
            connection.execute("""
                ALTER TABLE health_alerts
                ADD COLUMN resolved_by INTEGER
            """)

        if "is_resolved" not in alert_columns:
            connection.execute("""
                ALTER TABLE health_alerts
                ADD COLUMN is_resolved INTEGER DEFAULT 0
            """)

        if "mission_id" not in alert_columns:
            connection.execute("""
                ALTER TABLE health_alerts
                ADD COLUMN mission_id TEXT
            """)

        # --------------------------------------------------
        # MIGRATE MISSIONS TABLE
        # --------------------------------------------------

        mission_columns = {
            row["name"]
            for row in connection.execute(
                "PRAGMA table_info(missions)"
            ).fetchall()
        }

        if "created_by" not in mission_columns:
            connection.execute("""
                ALTER TABLE missions
                ADD COLUMN created_by INTEGER REFERENCES users(id)
            """)

        # --------------------------------------------------
        # DEFAULT DEMONSTRATION MISSION
        # --------------------------------------------------

        connection.execute("""
            INSERT OR IGNORE INTO missions (
                mission_id,
                mission_name,
                destination,
                launch_date,
                status,
                description
            )
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            "ORBIT-01",
            "Orbital Research Mission",
            "Low Earth Orbit",
            None,
            "Active",
            "Default demonstration mission for ASTRAcare."
        ))

        # --------------------------------------------------
        # NEW MISSION MEMBERSHIP TABLE
        # --------------------------------------------------

        connection.execute("""
            CREATE TABLE IF NOT EXISTS mission_members (
                user_id INTEGER NOT NULL,
                mission_id TEXT NOT NULL,
                mission_role TEXT NOT NULL
                    CHECK (
                        mission_role IN (
                            'Captain',
                            'Medic',
                            'Astronaut'
                        )
                    ),
                assigned_at TEXT DEFAULT CURRENT_TIMESTAMP,

                PRIMARY KEY (user_id, mission_id),

                FOREIGN KEY (user_id)
                    REFERENCES users(id)
                    ON DELETE CASCADE,

                FOREIGN KEY (mission_id)
                    REFERENCES missions(mission_id)
                    ON UPDATE CASCADE
                    ON DELETE CASCADE
            )
        """)

        # --------------------------------------------------
        # MIGRATE EXISTING CREW ASSIGNMENTS
        # --------------------------------------------------

        connection.execute("""
            INSERT OR IGNORE INTO mission_members (
                user_id,
                mission_id,
                mission_role
            )
            SELECT
                id,
                mission_id,
                CASE
                    WHEN mission_role IN (
                        'Captain',
                        'Medic',
                        'Astronaut'
                    )
                    THEN mission_role
                    ELSE 'Astronaut'
                END
            FROM users
            WHERE mission_id IS NOT NULL
              AND mission_id != ''
              AND EXISTS (
                  SELECT 1
                  FROM missions
                  WHERE missions.mission_id = users.mission_id
              )
        """)

        # --------------------------------------------------
        # ENFORCE ONE CAPTAIN PER MISSION
        # --------------------------------------------------

        connection.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS
            one_captain_per_mission
            ON mission_members(mission_id)
            WHERE mission_role = 'Captain'
        """)

        # --------------------------------------------------
        # ENFORCE MAXIMUM TWO MEDICS PER MISSION
        # --------------------------------------------------

        connection.execute("""
            CREATE TRIGGER IF NOT EXISTS
            limit_two_medics_insert
            BEFORE INSERT ON mission_members
            WHEN NEW.mission_role = 'Medic'
            AND (
                SELECT COUNT(*)
                FROM mission_members
                WHERE mission_id = NEW.mission_id
                  AND mission_role = 'Medic'
            ) >= 2
            BEGIN
                SELECT RAISE(
                    ABORT,
                    'A mission can have a maximum of two Medics.'
                );
            END
        """)

        connection.execute("""
            CREATE TRIGGER IF NOT EXISTS
            limit_two_medics_update
            BEFORE UPDATE OF mission_role, mission_id
            ON mission_members
            WHEN NEW.mission_role = 'Medic'
            AND (
                SELECT COUNT(*)
                FROM mission_members
                WHERE mission_id = NEW.mission_id
                  AND mission_role = 'Medic'
                  AND NOT (
                      user_id = OLD.user_id
                      AND mission_id = OLD.mission_id
                  )
            ) >= 2
            BEGIN
                SELECT RAISE(
                    ABORT,
                    'A mission can have a maximum of two Medics.'
                );
            END
        """)

        # --------------------------------------------------
        # MIGRATE EXISTING ALERTS TO THEIR MISSIONS
        # --------------------------------------------------

        connection.execute("""
            UPDATE health_alerts
            SET mission_id = (
                SELECT mm.mission_id
                FROM mission_members mm
                WHERE mm.user_id = health_alerts.user_id
                ORDER BY mm.assigned_at ASC
                LIMIT 1
            )
            WHERE mission_id IS NULL
        """)

        # --------------------------------------------------
        # SAMPLE READING
        # --------------------------------------------------

        count = connection.execute("""
            SELECT COUNT(*)
            FROM health_readings
        """).fetchone()[0]

        if count == 0:
            connection.execute("""
                INSERT INTO health_readings (
                    heart_rate,
                    spo2,
                    sleep_hours,
                    fatigue_level
                )
                VALUES (?, ?, ?, ?)
            """, (82, 97, 7.5, 3))


# --------------------------------------------------
# USER MISSION ROLE
# --------------------------------------------------

def get_user_mission_role(user_id, mission_id):

    with get_connection() as connection:

        result = connection.execute("""
            SELECT mission_role
            FROM mission_members
            WHERE user_id = ?
              AND mission_id = ?
        """, (user_id, mission_id)).fetchone()

        return result["mission_role"] if result else None


def get_mission_creator(mission_id):

    with get_connection() as connection:

        result = connection.execute("""
            SELECT created_by
            FROM missions
            WHERE mission_id = ?
        """, (mission_id,)).fetchone()

        return result["created_by"] if result else None


# --------------------------------------------------
# HEALTH READINGS
# --------------------------------------------------

def get_latest_reading(user_id=None):

    with get_connection() as connection:

        if user_id is None:
            reading = connection.execute("""
                SELECT *
                FROM health_readings
                ORDER BY id DESC
                LIMIT 1
            """).fetchone()

        else:
            reading = connection.execute("""
                SELECT *
                FROM health_readings
                WHERE user_id = ?
                ORDER BY id DESC
                LIMIT 1
            """, (user_id,)).fetchone()

        return dict(reading) if reading else None


def add_health_reading(
    heart_rate,
    spo2,
    sleep_hours,
    fatigue_level,
    user_id=None,
    mission_id=None
):

    with get_connection() as connection:

        cursor = connection.execute("""
            INSERT INTO health_readings (
                user_id,
                mission_id,
                heart_rate,
                spo2,
                sleep_hours,
                fatigue_level
            )
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            user_id,
            mission_id,
            heart_rate,
            spo2,
            sleep_hours,
            fatigue_level
        ))

        reading_id = cursor.lastrowid

        alerts = []

        if heart_rate < 60:
            alerts.append("Low simulated heart rate detected.")

        if heart_rate > 100:
            alerts.append("High simulated heart rate detected.")

        if spo2 < 95:
            alerts.append("Low simulated blood oxygen reading detected.")

        if sleep_hours < 6:
            alerts.append("Short sleep duration detected.")

        if fatigue_level >= 7:
            alerts.append("High fatigue score detected.")

        if user_id is not None:

            if mission_id is not None:
                memberships = [mission_id]

            else:
                memberships = [
                    row["mission_id"]
                    for row in connection.execute("""
                        SELECT mission_id
                        FROM mission_members
                        WHERE user_id = ?
                    """, (user_id,)).fetchall()
                ]

            for assigned_mission in memberships:

                for alert in alerts:

                    existing_alert = connection.execute("""
                        SELECT id
                        FROM health_alerts
                        WHERE user_id = ?
                          AND mission_id = ?
                          AND alert_message = ?
                          AND is_resolved = 0
                    """, (
                        user_id,
                        assigned_mission,
                        alert
                    )).fetchone()

                    if existing_alert is None:

                        connection.execute("""
                            INSERT INTO health_alerts (
                                user_id,
                                reading_id,
                                mission_id,
                                alert_message
                            )
                            VALUES (?, ?, ?, ?)
                        """, (
                            user_id,
                            reading_id,
                            assigned_mission,
                            alert
                        ))

        return reading_id


def get_health_history(user_id=None):

    with get_connection() as connection:

        if user_id is None:
            readings = connection.execute("""
                SELECT *
                FROM health_readings
                ORDER BY id DESC
                LIMIT 20
            """).fetchall()

        else:
            readings = connection.execute("""
                SELECT *
                FROM health_readings
                WHERE user_id = ?
                ORDER BY id DESC
                LIMIT 20
            """, (user_id,)).fetchall()

        return [dict(reading) for reading in reversed(readings)]


def get_total_readings_count(user_id=None):

    with get_connection() as connection:

        if user_id is None:
            count = connection.execute("""
                SELECT COUNT(*)
                FROM health_readings
            """).fetchone()[0]

        else:
            count = connection.execute("""
                SELECT COUNT(*)
                FROM health_readings
                WHERE user_id = ?
            """, (user_id,)).fetchone()[0]

        return count


# --------------------------------------------------
# USER ACCOUNTS
# --------------------------------------------------

def create_user(name, email, password_hash):

    with get_connection() as connection:

        cursor = connection.execute("""
            INSERT INTO users (
                name,
                email,
                password_hash,
                mission_id,
                mission_role
            )
            VALUES (?, ?, ?, NULL, 'Astronaut')
        """, (name, email, password_hash))

        user_id = cursor.lastrowid

        crew_id = f"AST-{user_id:03d}"

        connection.execute("""
            UPDATE users
            SET crew_id = ?
            WHERE id = ?
        """, (crew_id, user_id))

        return user_id


def get_user_by_email(email):

    with get_connection() as connection:

        user = connection.execute("""
            SELECT *
            FROM users
            WHERE email = ?
        """, (email,)).fetchone()

        return dict(user) if user else None


def get_user_by_id(user_id):

    with get_connection() as connection:

        user = connection.execute("""
            SELECT
                id,
                name,
                email,
                crew_id,
                mission_id,
                mission_role,
                created_at
            FROM users
            WHERE id = ?
        """, (user_id,)).fetchone()

        return dict(user) if user else None


def get_all_users():

    with get_connection() as connection:

        users = connection.execute("""
            SELECT
                id,
                name,
                email,
                crew_id,
                mission_id,
                mission_role
            FROM users
            ORDER BY name ASC
        """).fetchall()

        return [dict(user) for user in users]


# --------------------------------------------------
# MISSION CREW
# --------------------------------------------------

def get_users_assigned_to_mission(mission_id):

    with get_connection() as connection:

        users = connection.execute("""
            SELECT
                u.id,
                u.name,
                u.email,
                u.crew_id,
                mm.mission_role,
                mm.assigned_at,
                hr.heart_rate,
                hr.spo2,
                hr.sleep_hours,
                hr.fatigue_level,
                hr.recorded_at
            FROM mission_members mm
            JOIN users u
                ON u.id = mm.user_id
            LEFT JOIN health_readings hr
                ON hr.user_id = u.id
                AND hr.mission_id = mm.mission_id
                AND hr.id = (
                    SELECT MAX(hr2.id)
                    FROM health_readings hr2
                    WHERE hr2.user_id = u.id
                    AND hr2.mission_id = mm.mission_id
                )
            WHERE mm.mission_id = ?
            ORDER BY u.name ASC
        """, (mission_id,)).fetchall()

        return [dict(user) for user in users]


def get_health_history_for_mission(mission_id):

    with get_connection() as connection:

        readings = connection.execute("""
            SELECT
                hr.*,
                u.name,
                u.crew_id,
                mm.mission_role
            FROM health_readings hr
            JOIN users u
                ON hr.user_id = u.id
            JOIN mission_members mm
                ON mm.user_id = u.id
               AND mm.mission_id = hr.mission_id
            WHERE hr.mission_id = ?
            ORDER BY hr.recorded_at DESC, hr.id DESC
        """, (mission_id,)).fetchall()

        return [dict(reading) for reading in readings]


# --------------------------------------------------
# USER PROFILE
# --------------------------------------------------

def update_user_profile(user_id, name):

    with get_connection() as connection:

        cursor = connection.execute("""
            UPDATE users
            SET name = ?
            WHERE id = ?
        """, (name, user_id))

        return cursor.rowcount


# --------------------------------------------------
# MISSION INFORMATION
# --------------------------------------------------

def get_mission_by_id(mission_id):

    with get_connection() as connection:

        mission = connection.execute("""
            SELECT
                m.*,
                u.name AS captain_name
            FROM missions m
            LEFT JOIN mission_members mm
                ON mm.mission_id = m.mission_id
                AND mm.mission_role = 'Captain'
            LEFT JOIN users u
                ON u.id = mm.user_id
            WHERE m.mission_id = ?
        """, (mission_id,)).fetchone()

        return dict(mission) if mission else None


def get_all_missions():

    with get_connection() as connection:

        missions = connection.execute("""
            SELECT
                m.*,
                u.name AS captain_name,
                (
                    SELECT COUNT(*)
                    FROM mission_members mm2
                    WHERE mm2.mission_id = m.mission_id
                ) AS crew_count
            FROM missions m
            LEFT JOIN mission_members mm
                ON mm.mission_id = m.mission_id
                AND mm.mission_role = 'Captain'
            LEFT JOIN users u
                ON u.id = mm.user_id
            ORDER BY m.created_at DESC
        """).fetchall()

        return [dict(mission) for mission in missions]


def create_mission(
    mission_id,
    mission_name,
    destination,
    launch_date,
    status,
    description,
    created_by=None
):

    with get_connection() as connection:

        cursor = connection.execute("""
            INSERT INTO missions (
                mission_id,
                mission_name,
                destination,
                launch_date,
                status,
                description,
                created_by
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            mission_id,
            mission_name,
            destination,
            launch_date,
            status,
            description,
            created_by
        ))

        return cursor.rowcount


# --------------------------------------------------
# ASSIGN CREW TO A MISSION
# --------------------------------------------------

def assign_user_to_mission(user_id, mission_id, mission_role):

    allowed_roles = ["Captain", "Medic", "Astronaut"]

    if mission_role not in allowed_roles:
        return False, "Invalid crew role."

    with get_connection() as connection:

        connection.execute("BEGIN IMMEDIATE")

        mission = connection.execute("""
            SELECT mission_id
            FROM missions
            WHERE mission_id = ?
        """, (mission_id,)).fetchone()

        if mission is None:
            return False, "Mission not found."

        astronaut = connection.execute("""
            SELECT id
            FROM users
            WHERE id = ?
        """, (user_id,)).fetchone()

        if astronaut is None:
            return False, "Astronaut account not found."

        existing_membership = connection.execute("""
            SELECT mission_role
            FROM mission_members
            WHERE user_id = ?
              AND mission_id = ?
        """, (user_id, mission_id)).fetchone()

        # Do not allow ordinary assignment to change
        # an existing Captain's role.
        if (
            existing_membership is not None
            and existing_membership["mission_role"] == "Captain"
            and mission_role != "Captain"
        ):
            return False, (
                "The Captain role requires a command handover."
            )

        if existing_membership is None and mission_role == "Captain":

            existing_captain = connection.execute("""
                SELECT user_id
                FROM mission_members
                WHERE mission_id = ?
                  AND mission_role = 'Captain'
            """, (mission_id,)).fetchone()

            if existing_captain is not None:
                return False, "This mission already has a Captain."

        if mission_role == "Medic":

            medic_count = connection.execute("""
                SELECT COUNT(*)
                FROM mission_members
                WHERE mission_id = ?
                  AND mission_role = 'Medic'
                  AND user_id != ?
            """, (mission_id, user_id)).fetchone()[0]

            if medic_count >= 2:
                return False, (
                    "This mission already has its maximum "
                    "number of Medics."
                )

        try:

            connection.execute("""
                INSERT INTO mission_members (
                    user_id,
                    mission_id,
                    mission_role
                )
                VALUES (?, ?, ?)

                ON CONFLICT(user_id, mission_id)
                DO UPDATE SET
                    mission_role = excluded.mission_role
            """, (user_id, mission_id, mission_role))

        except sqlite3.IntegrityError as error:

            return False, str(error)

        # Legacy compatibility only.
        # Authorization must use mission_members.
        connection.execute("""
            UPDATE users
            SET mission_id = ?,
                mission_role = ?
            WHERE id = ?
        """, (mission_id, mission_role, user_id))

        return True, "Crew member assigned successfully."


# --------------------------------------------------
# UNASSIGN CREW FROM A MISSION
# --------------------------------------------------

def unassign_user_from_mission(user_id, mission_id):

    with get_connection() as connection:

        membership = connection.execute("""
            SELECT mission_role
            FROM mission_members
            WHERE user_id = ?
              AND mission_id = ?
        """, (user_id, mission_id)).fetchone()

        if membership is None:
            return 0

        if membership["mission_role"] == "Captain":
            return 0

        cursor = connection.execute("""
            DELETE FROM mission_members
            WHERE user_id = ?
              AND mission_id = ?
        """, (user_id, mission_id))

        # Update legacy fields without affecting
        # memberships in other missions.
        remaining_membership = connection.execute("""
            SELECT mission_id, mission_role
            FROM mission_members
            WHERE user_id = ?
            ORDER BY assigned_at DESC
            LIMIT 1
        """, (user_id,)).fetchone()

        if remaining_membership:

            connection.execute("""
                UPDATE users
                SET mission_id = ?,
                    mission_role = ?
                WHERE id = ?
            """, (
                remaining_membership["mission_id"],
                remaining_membership["mission_role"],
                user_id
            ))

        else:

            connection.execute("""
                UPDATE users
                SET mission_id = NULL,
                    mission_role = 'Astronaut'
                WHERE id = ?
            """, (user_id,))

        return cursor.rowcount


# --------------------------------------------------
# UPDATE MISSION
# --------------------------------------------------

def update_mission(
    original_id,
    mission_id,
    mission_name,
    destination,
    launch_date,
    status,
    description
):

    with get_connection() as connection:

        cursor = connection.execute("""
            UPDATE missions
            SET mission_id = ?,
                mission_name = ?,
                destination = ?,
                launch_date = ?,
                status = ?,
                description = ?
            WHERE mission_id = ?
        """, (
            mission_id,
            mission_name,
            destination,
            launch_date,
            status,
            description,
            original_id
        ))

        return cursor.rowcount


def update_mission_status(mission_id, status):

    with get_connection() as connection:

        cursor = connection.execute("""
            UPDATE missions
            SET status = ?
            WHERE mission_id = ?
        """, (status, mission_id))

        return cursor.rowcount


# --------------------------------------------------
# DELETE MISSION
# --------------------------------------------------

def delete_mission(mission_id):

    with get_connection() as connection:

        # Remove mission-specific alerts.
        connection.execute("""
            DELETE FROM health_alerts
            WHERE mission_id = ?
        """, (mission_id,))

        # Remove all memberships for this mission.
        connection.execute("""
            DELETE FROM mission_members
            WHERE mission_id = ?
        """, (mission_id,))

        # Clear legacy fields for affected users.
        connection.execute("""
            UPDATE users
            SET mission_id = NULL,
                mission_role = 'Astronaut'
            WHERE mission_id = ?
        """, (mission_id,))

        cursor = connection.execute("""
            DELETE FROM missions
            WHERE mission_id = ?
        """, (mission_id,))

        return cursor.rowcount


# --------------------------------------------------
# HEALTH ALERTS
# --------------------------------------------------

def get_health_alert_by_id(alert_id):

    with get_connection() as connection:

        alert = connection.execute("""
            SELECT
                ha.id,
                ha.user_id,
                ha.mission_id,
                ha.alert_message,
                ha.is_resolved
            FROM health_alerts ha
            WHERE ha.id = ?
        """, (alert_id,)).fetchone()

        return dict(alert) if alert else None


def get_health_alerts_for_mission(mission_id):

    with get_connection() as connection:

        alerts = connection.execute("""
            SELECT
                ha.id,
                ha.user_id,
                ha.mission_id,
                ha.alert_message,
                ha.created_at,
                ha.is_resolved,
                u.name,
                u.crew_id,
                hr.heart_rate,
                hr.spo2,
                hr.sleep_hours,
                hr.fatigue_level
            FROM health_alerts ha
            JOIN users u
                ON ha.user_id = u.id
            JOIN health_readings hr
                ON ha.reading_id = hr.id
            WHERE ha.mission_id = ?
              AND ha.is_resolved = 0
            ORDER BY ha.created_at DESC
        """, (mission_id,)).fetchall()

        return [dict(alert) for alert in alerts]


def resolve_health_alert(alert_id, resolved_by):

    with get_connection() as connection:

        cursor = connection.execute("""
            UPDATE health_alerts
            SET
                is_resolved = 1,
                resolved_at = CURRENT_TIMESTAMP,
                resolved_by = ?
            WHERE id = ?
              AND is_resolved = 0
        """, (resolved_by, alert_id))

        return cursor.rowcount > 0


if __name__ == "__main__":
    import sqlite3

    connection = sqlite3.connect("data/astracare.db")

    try:
        # Set Albert as the creator of Mission Mars
        connection.execute("""
            UPDATE missions
            SET created_by = 1
            WHERE mission_id = 'ORBIT-02'
        """)

        # Assign Albert as Captain of Mission Mars
        connection.execute("""
            INSERT INTO mission_members (
                user_id, mission_id, mission_role
            )
            VALUES (1, 'ORBIT-02', 'Captain')
            ON CONFLICT(user_id, mission_id)
            DO UPDATE SET mission_role = 'Captain'
        """)

        # Update legacy compatibility fields
        connection.execute("""
            UPDATE users
            SET mission_id = 'ORBIT-02',
                mission_role = 'Captain'
            WHERE id = 1
        """)

        connection.commit()

        print("Albert assigned as Captain of ORBIT-02!")

        print(connection.execute("""
            SELECT mission_id, mission_name, created_by
            FROM missions
            WHERE mission_id = 'ORBIT-02'
        """).fetchall())

        print(connection.execute("""
            SELECT user_id, mission_role
            FROM mission_members
            WHERE mission_id = 'ORBIT-02'
        """).fetchall())

    except Exception:
        connection.rollback()
        raise

    finally:
        connection.close()
