
const charts = {};

function createOrUpdateChart(canvasId, label, labels, values) {

    const canvas = document.getElementById(canvasId);

    if (!canvas) return;

    if (charts[canvasId]) {
        charts[canvasId].data.labels = labels;
        charts[canvasId].data.datasets[0].data = values;
        charts[canvasId].update();
        return;
    }

    charts[canvasId] = new Chart(canvas, {
        type: "line",

        data: {
            labels: labels,

            datasets: [{
                label: label,
                data: values,
                borderColor: "#38bdf8",
                backgroundColor: "rgba(56, 189, 248, 0.15)",
                pointBackgroundColor: "#38bdf8",
                pointBorderColor: "#e0f2fe",
                pointRadius: 4,
                borderWidth: 2,
                tension: 0.3,
                fill: false
            }]
        },

        options: {
            responsive: true,
            maintainAspectRatio: false,

            plugins: {
                legend: {
                    labels: {
                        color: "#dbeafe",
                        font: {
                            size: 12
                        }
                    }
                }
            },

            scales: {
                x: {
                    ticks: {
                        color: "#7dd3fc",
                        font: {
                            size: 11
                        }
                    },
                    grid: {
                        color: "rgba(148, 163, 184, 0.12)"
                    }
                },

                y: {
                    beginAtZero: false,

                    ticks: {
                        color: "#7dd3fc"
                    },

                    grid: {
                        color: "rgba(148, 163, 184, 0.18)"
                    }
                }
            }
        }
    });
}


async function updateAnalytics() {

    try {
        const response = await fetch("/api/history");

        if (!response.ok) {
            throw new Error("Could not load health history");
        }

        const history = await response.json();

        if (history.length === 0) return;


        // Display the latest 10 readings, newest first
        const recentReadings = history.slice(-10).reverse();

        const tableBody = document.getElementById("recent-readings-body");

        if (tableBody) {

            tableBody.replaceChildren();

            recentReadings.forEach(function(item) {

                const row = document.createElement("tr");

                const hasAlert =
                    item.heart_rate > 100 ||
                    item.heart_rate < 50 ||
                    item.spo2 < 90 ||
                    item.sleep_hours < 6 ||
                    item.fatigue_level >= 7;

                row.className = hasAlert ? "alert-row" : "normal-row";

                const recordedAt = new Date(
                    item.recorded_at.replace(" ", "T")
                ).toLocaleString();

                const values = [
                    recordedAt,
                    item.heart_rate + " BPM",
                    item.spo2 + "%",
                    item.sleep_hours + " hrs",
                    item.fatigue_level + "/10",
                    hasAlert ? "⚠ Alert" : "✓ Normal"
                ];

                values.forEach(function(value) {
                    const cell = document.createElement("td");
                    cell.textContent = value;
                    row.appendChild(cell);
                });

                tableBody.appendChild(row);
            });
        }

        const labels = history.map(item =>
            new Date(item.recorded_at.replace(" ", "T"))
                .toLocaleTimeString()
        );

        createOrUpdateChart(
            "heartRateChart",
            "Heart Rate (BPM)",
            labels,
            history.map(item => item.heart_rate)
        );

        createOrUpdateChart(
            "spo2Chart",
            "Blood Oxygen (%)",
            labels,
            history.map(item => item.spo2)
        );

        createOrUpdateChart(
            "sleepChart",
            "Sleep (Hours)",
            labels,
            history.map(item => item.sleep_hours)
        );

        createOrUpdateChart(
            "fatigueChart",
            "Fatigue (0-10)",
            labels,
            history.map(item => item.fatigue_level)
        );

    } catch (error) {
        console.error("Analytics update failed:", error);
    }
}

updateAnalytics();

setInterval(updateAnalytics, 5000);
