
// ============================================
// ASTRAcare - HEALTH DASHBOARD
// ============================================


// Get the currently selected mission
function getSelectedMission() {
    const missionSelector = document.getElementById("reading-mission");

    return missionSelector ? missionSelector.value : null;
}


// Display health values on the dashboard
function updateHealthValues(reading) {

    if (!reading) {
        return;
    }

    const healthCards = document.querySelectorAll(
        ".health-cards .health-card .health-value"
    );

    if (healthCards.length >= 4) {
        healthCards[0].textContent = reading.heart_rate + " BPM";
        healthCards[1].textContent = reading.spo2 + " %";
        healthCards[2].textContent = reading.sleep_hours + " Hours";
        healthCards[3].textContent = reading.fatigue_level + " / 10";
    }
}


// Display health alerts
function updateHealthAlerts(alerts) {

    const alertSection = document.getElementById("health-alert-list");

    if (!alertSection) {
        return;
    }

    alertSection.replaceChildren();

    if (alerts && alerts.length > 0) {

        alerts.forEach(function(alert) {

            const alertCard = document.createElement("div");
            alertCard.className = "alert-card";

            const heading = document.createElement("strong");
            heading.textContent = "⚠️ Health Warning";

            const paragraph = document.createElement("p");
            paragraph.textContent = alert;

            alertCard.appendChild(heading);
            alertCard.appendChild(paragraph);

            alertSection.appendChild(alertCard);

        });

    } else {

        const alertCard = document.createElement("div");
        alertCard.className = "alert-card";

        const heading = document.createElement("strong");
        heading.textContent = "✅ No Current Alerts";

        const paragraph = document.createElement("p");
        paragraph.textContent =
            "No health anomalies detected in the latest reading.";

        alertCard.appendChild(heading);
        alertCard.appendChild(paragraph);

        alertSection.appendChild(alertCard);
    }

    const disclaimer = document.createElement("small");

    disclaimer.textContent =
        "Illustrative alerts based on health readings. Not a medical diagnosis.";

    alertSection.appendChild(disclaimer);
}


// ============================================
// FETCH LATEST HEALTH READING
// ============================================

async function updateHealthDashboard() {

    try {

        const missionId = getSelectedMission();

        if (!missionId) {
            return;
        }

        const response = await fetch(
            "/api/readings?mission_id=" + encodeURIComponent(missionId)
        );

        if (!response.ok) {
            throw new Error("Could not fetch health readings.");
        }

        const data = await response.json();

        if (data.reading) {
            updateHealthValues(data.reading);
        }

        updateHealthAlerts(data.alerts || []);

    } catch (error) {

        console.error("Dashboard update failed:", error);

    }
}


// ============================================
// HANDLE MISSION SELECTION
// ============================================

const missionSelector = document.getElementById("reading-mission");

if (missionSelector) {

    missionSelector.addEventListener("change", function() {

        // Refresh dashboard data for the selected mission
        updateHealthDashboard();

    });

}


// ============================================
// HANDLE ADD HEALTH READING FORM
// ============================================

const readingForm = document.getElementById("reading-form");

if (readingForm) {

    readingForm.addEventListener("submit", async function(event) {

        event.preventDefault();

        const submitButton = document.getElementById("submit-reading");

        const message = document.getElementById("reading-message");

        const missionId = getSelectedMission();

        if (!missionId) {

            message.textContent =
                "❌ Please select a mission first.";

            message.style.color = "#ef4444";

            return;
        }

        submitButton.disabled = true;

        submitButton.textContent = "Saving...";

        message.textContent = "";


        // Collect health reading and selected mission
        const reading = {

            mission_id: missionId,

            heart_rate: Number(
                document.getElementById("input-heart-rate").value
            ),

            spo2: Number(
                document.getElementById("input-spo2").value
            ),

            sleep_hours: Number(
                document.getElementById("input-sleep").value
            ),

            fatigue_level: Number(
                document.getElementById("input-fatigue").value
            )

        };


        try {

            const response = await fetch("/api/readings", {

                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify(reading)

            });


            const data = await response.json();


            if (!response.ok) {

                throw new Error(
                    data.error || "Unable to save health reading."
                );

            }


            message.textContent =
                "✅ Health reading saved successfully!";

            message.style.color = "#22c55e";


            // Clear only the health input fields.
            // Keep the selected mission.
            document.getElementById("input-heart-rate").value = "";

            document.getElementById("input-spo2").value = "";

            document.getElementById("input-sleep").value = "";

            document.getElementById("input-fatigue").value = "";


            // Refresh dashboard data
            await updateHealthDashboard();


            // Refresh charts and summary data
            if (typeof updateAnalytics === "function") {
                updateAnalytics();
            }

            if (typeof updateSummary === "function") {
                updateSummary();
            }


            // Reload after saving so server-rendered sections
            // also display the latest mission data.
            setTimeout(function() {

                window.location.reload();

            }, 1000);


        } catch (error) {

            message.textContent = "❌ " + error.message;

            message.style.color = "#ef4444";


        } finally {

            submitButton.disabled = false;

            submitButton.textContent = "Save Health Reading";

        }

    });

}


// ============================================
// AUTOMATIC DASHBOARD REFRESH
// ============================================

// Update immediately
updateHealthDashboard();

// Refresh every 5 seconds
setInterval(updateHealthDashboard, 5000);
