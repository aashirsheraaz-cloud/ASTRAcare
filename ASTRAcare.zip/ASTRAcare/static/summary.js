
async function updateSummary() {

    try {
        const response = await fetch("/api/summary");

        if (!response.ok) {
            throw new Error("Could not load dashboard summary");
        }

        const data = await response.json();

        document.getElementById("total-readings").textContent =
            data.total_readings;

        document.getElementById("average-heart-rate").textContent =
            data.average_heart_rate;

        document.getElementById("average-spo2").textContent =
            data.average_spo2;

        document.getElementById("active-alerts").textContent =
            data.active_alerts;

    } catch (error) {
        console.error("Summary update failed:", error);
    }
}

updateSummary();

setInterval(updateSummary, 5000);
