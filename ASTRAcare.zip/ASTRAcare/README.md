# 🚀 ASTRAcare – Astronaut Health Monitoring System

**ASTRAcare** is a web-based Astronaut Health Monitoring System developed using Python, Flask, and SQLite. It is designed to monitor astronaut health readings, manage mission crews, identify potential health anomalies, and provide health analytics through a centralized dashboard.

The system simulates a space mission environment where different crew members have specific roles and permissions.

---

## 🌌 Project Overview

Astronauts operating in space environments require continuous health monitoring. ASTRAcare provides a digital platform to record and monitor important health indicators, including:

- Heart Rate (BPM)
- Blood Oxygen Saturation (SpO2)
- Sleep Duration (Hours)
- Fatigue Level (1–10)

The application stores health readings, displays historical trends, and generates alerts when readings exceed predefined thresholds.

---

## ✨ Features

### 👨‍🚀 User Authentication
- User registration and login.
- Secure password hashing.
- Session-based authentication.
- Personalized astronaut profiles.

### 🛰️ Mission Management
- Create and manage missions.
- Assign and unassign crew members.
- Support multiple missions.
- Assign mission-specific roles.

### 👥 Role-Based Access Control

ASTRAcare supports three mission roles:

| Role | Responsibilities |
|---|---|
| Captain | Manage mission crew, edit missions, view crew health information and alerts. |
| Medic | Monitor crew health, view alerts, record new readings and resolve alerts after reassessment. |
| Astronaut | View mission details, crew profiles and the latest crew health readings. |

Permissions are managed separately for each mission.

### ❤️ Health Monitoring
- Record astronaut health readings.
- Display the latest health information.
- Associate readings with specific missions.
- Maintain historical health records.

### ⚠️ Health Alerts
The system identifies potential health anomalies using predefined thresholds:

- Heart rate below 60 BPM or above 100 BPM.
- Blood oxygen saturation below 95%.
- Sleep duration below 6 hours.
- Fatigue level of 7 or higher.

Medics can reassess an astronaut by recording a new health reading and resolve an alert when the recovery conditions are satisfied.

### 📊 Health Analytics
- Historical health charts.
- Average heart rate and SpO2.
- Total reading count.
- Health trend visualization.
- Recent health reading records.

---

## 🛠️ Technologies Used

| Technology | Purpose |
|---|---|
| Python | Backend programming |
| Flask | Web application framework |
| SQLite | Database management |
| HTML5 | Web page structure |
| CSS3 | Styling and layout |
| JavaScript | Dashboard interactions |
| Chart.js | Health data visualization |
| Werkzeug | Password hashing and security utilities |
| Git & GitHub | Version control and project hosting |

---

## 📁 Project Structure

```text
ASTRAcare/
│
├── backend/
│   ├── app.py
│   ├── database.py
│   │
│   └── templates/
│       ├── index.html
│       ├── register.html
│       ├── login.html
│       ├── missions.html
│       └── mission_details.html
│
├── frontend/
│
├── static/
│   ├── style.css
│   ├── dashboard.js
│   ├── analytics.js
│   └── summary.js
│
├── data/
│   └── astracare.db
│
├── docs/
│
├── .gitignore
└── README.md
```

---

## ⚙️ Installation and Setup

### 1. Clone the Repository

```bash
git clone https://github.com/YOUR-USERNAME/ASTRAcare.git
```

### 2. Navigate to the Project Folder

```bash
cd ASTRAcare
```

### 3. Create a Virtual Environment

```bash
python -m venv .venv
```

### 4. Activate the Virtual Environment

**Windows PowerShell:**

```powershell
.\.venv\Scripts\Activate.ps1
```

### 5. Install Dependencies

```bash
pip install Flask
```

### 6. Run the Application

```bash
python backend/app.py
```

### 7. Open ASTRAcare

Open your browser and visit:

```text
http://127.0.0.1:5000
```

---

## 🔐 Security and Access Control

ASTRAcare incorporates:

- Password hashing instead of storing plain-text passwords.
- Session-based user authentication.
- Protected application routes.
- Mission-specific role verification.
- User-specific and mission-specific health data access.

---

## ⚠️ Disclaimer

ASTRAcare is an educational software project that uses simulated health readings and illustrative health alert thresholds.

It is not a certified medical device and does not provide professional medical diagnoses or validated spacecraft medical procedures.

---

## 🎯 Project Objective

The main objective of ASTRAcare is to demonstrate how a web-based information system can support astronaut health monitoring, mission crew management, database operations, role-based access control, and health data visualization.

**Developed as an academic software project.**

---

## 👨‍💻 Author

**ASTRAcare Development Project**

